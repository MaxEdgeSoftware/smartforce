// Swicher
function setTheme(theme) {
    document.getElementById('theme-opt').href = 'assets/css/' + theme + '.css';
};