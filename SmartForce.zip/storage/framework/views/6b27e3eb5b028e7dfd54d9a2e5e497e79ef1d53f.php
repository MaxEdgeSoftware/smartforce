<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Yemi Maxedge\laravel\SmartForce\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>