<?php $__env->startComponent('mail::message'); ?>

Dear <?php echo e($data["name"]); ?> , <br>

Welcome to SMARTFORCE. Please verify your email.
To verify your email Please click on the provided link <a href="<?php echo e(env('APP_URL')); ?>/verify-me/<?php echo e($data['email']); ?>/<?php echo e($data['token']); ?>">click here</a>.




<?php $__env->startComponent('mail::button', ['url' => env('APP_URL').'/verify-me/'.$data["email"].'/'.$data["token"]]); ?>
VERIFY ME
<?php echo $__env->renderComponent(); ?>

Thanks and Regards,<br>
Team <?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH C:\Users\Yemi Maxedge\laravel\SmartForce\resources\views/emails/verify.blade.php ENDPATH**/ ?>