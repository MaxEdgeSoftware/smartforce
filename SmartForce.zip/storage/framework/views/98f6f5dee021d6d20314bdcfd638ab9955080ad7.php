


<?php $__env->startSection("content"); ?>
<div class="container-fluid">
    <div>
        <p class="text-muted">Welcome back, <?php echo e(auth()->user()->first_name); ?></p>
        <h6 class="fs-11">Dashboard</h6>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.dashboard", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yemi Maxedge\laravel\SmartForce\resources\views/dashboard/index.blade.php ENDPATH**/ ?>