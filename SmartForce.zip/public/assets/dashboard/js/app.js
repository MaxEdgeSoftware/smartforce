function toggleSidebar() {
    document.querySelector(".page-wrapper").classList.toggle("toggled")
    document.querySelector(".main").classList.toggle("unToggled")
}