


<?php $__env->startSection("content"); ?>
<div class="page_header">
    <h3 class="text-dark">All Jobs</h3>
    <a class="btn btn-link text-dark" href="/management/job/add">Add</a>
</div>

<section>
    <div class="card p-2">

        <div class="card-body p-3">
            <div class="table-responsive">
                <table class="table table-striped" id="jobsTable">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Duration</th>
                            <th>Payment Mode</th>
                            <th>Rate</th>
                            <th>Company</th>
                            <th>Location</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($job->title); ?></td>
                            <td><?php echo e($job->Category->title); ?></td>
                            <td><?php echo e($job->duration); ?></td>
                            <td><?php echo e($job->paymentMode); ?></td>
                            <td><?php echo e($job->rate); ?></td>
                            <td><?php echo e($job->company); ?></td>
                            <td><?php echo e($job->location); ?></td>

                            <td><a href="/management/job/<?php echo e($job->id); ?>" class="btn btn-success">View</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.management", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yemi Maxedge\laravel\SmartForce\resources\views/job/index.blade.php ENDPATH**/ ?>