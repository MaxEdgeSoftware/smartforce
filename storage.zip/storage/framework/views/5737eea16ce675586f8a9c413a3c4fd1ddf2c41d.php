


<?php $__env->startSection("content"); ?>


<section>
    <div class="row ">
        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <div class="card">
                <div class="card-statistic-4">
                    <div class="align-items-center justify-content-between">
                        <div class="row ">
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                                <div class="card-content">
                                    <h5 class="font-15">All Users</h5>
                                    <h2 class="mb-3 font-18"><?php echo e(count($users)); ?></h2>
                                    <!-- <p class="mb-0"><span class="col-green">10%</span> Increase</p> -->
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                                <div class="banner-img">
                                    <img class="p-3" style="height: 100px; width: 100px; object-fit: contain;" src="/admin/assets/img/banner/1.png" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <div class="card">
                <div class="card-statistic-4">
                    <div class="align-items-center justify-content-between">
                        <div class="row ">
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                                <div class="card-content">
                                    <h5 class="font-15">Job Categories</h5>
                                    <h2 class="mb-3 font-18"><?php echo e(count($categories)); ?></h2>
                                    <!-- <p class="mb-0"><span class="col-orange">09%</span> Decrease</p> -->
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                                <div class="banner-img">
                                    <img class="p-2 img-fluid" style="height: 100px; width: 100px; object-fit: contain" src="/admin/assets/img/banner/6.png" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <div class="card">
                <div class="card-statistic-4">
                    <div class="align-items-center justify-content-between">
                        <div class="row ">
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                                <div class="card-content">
                                    <h5 class="font-15">Jobs</h5>
                                    <h2 class="mb-3 font-18"><?php echo e(count($jobs)); ?></h2>
                                    <!-- <p class="mb-0"><span class="col-green">18%</span> -->
                                    <!-- Increase</p> -->
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                                <div class="banner-img">
                                    <img class="p-2 img-fluid" style="height: 100px; width: 100px; object-fit: contain" src="/admin/assets/img/banner/5.png" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <div class="card">
                <div class="card-statistic-4">
                    <div class="align-items-center justify-content-between">
                        <div class="row ">
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                                <div class="card-content">
                                    <h5 class="font-15">Settings</h5>

                                    <!-- <p class="mb-0"><span class="col-green">42%</span> Increase</p> -->
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                                <div class="banner-img">
                                    <img class="p-2 img-fluid" style="height: 100px; width: 100px; object-fit: contain" src="/admin/assets/img/banner/4.png" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>




    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4>Candidates</h4>
                </div>
                <div class="card-body p-3">
                    <div class="table-responsive">
                        <table class="table table-striped" id="agentsTable">
                            <thead>
                                <tr>
                                    <th>Full Name</th>
                                    <th>Email</th>
                                    <th>Mobile</th>
                                    <th>Gender</th>
                                    <th>Interest</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $regcomplete; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>

                                    <td><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->Profile->mobile); ?></td>
                                    <td><?php echo e($user->Profile->gender); ?></td>
                                    <td><?php echo e($user->Profile->Pinterest->title); ?></td>
                                    <td>
                                        <?php if($user->status == true): ?>
                                        <span class="text-uppercase badge badge-success">Verified</span>
                                        <?php else: ?>
                                        <span class="text-uppercase badge badge-danger">Not Verified</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><a href="/management/user/<?php echo e($user->id); ?>" class="btn btn-success">View</a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.management", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yemi Maxedge\laravel\SmartForce\resources\views/management/index.blade.php ENDPATH**/ ?>