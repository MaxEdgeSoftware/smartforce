


<?php $__env->startSection("content"); ?>
<div class="page_header">
    <h3 class="text-dark">Assign Job</h3>
    <small><?php echo e($category->title); ?></small>
</div>

<section class="section">
    <?php if(Session::has('status')): ?>
    <div class="alert alert-success">
        Job assigned successfully.... <a class="btn btn-link" href="/management/workers">Go to workers</a>
    </div>
    <?php endif; ?>
    <div class="container">
        <div class="row clearfix my-4">
            <div class="col-xl-6 col-lg-6 col-md-12">
                <div class="card profile-header">
                    <div class="body">
                        <div class="row p-2 py-3">


                            <?php if($user->Profile != null): ?>
                            <div class="col-lg-4 col-md-4 col-12">
                                <div class="profile-image float-md-right"> <img src="/storage/<?php echo e($user->Profile->picture); ?>" alt="">
                                </div>
                            </div>
                            <?php endif; ?>
                            <div class="col-lg-8 col-md-8 col-12">
                                <h4 class="mt-0 mb-0 text-uppercase color_black"><strong> <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></strong></h4>
                                <span class="job_post color_black">Candidate</span>
                                <?php if($user->Profile != null): ?>
                                <p class="m-0 color_black"><?php echo e($user->Profile->location); ?></p>
                                <?php endif; ?>
                                <p class="color_black"><?php echo e($user->email); ?></p>
                                <div class="d-flex">
                                    <?php if($user->status == true): ?>
                                    <form action="<?php echo e(route('updateUserStatus', $user->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input hidden value="0" name="status" />
                                        <button class="btn filled-button bg-danger">Block</button>
                                    </form>
                                    <?php else: ?>
                                    <form action="<?php echo e(route('updateUserStatus', $user->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input hidden value="1" name="status" />
                                        <button class="btn filled-button bg-danger">Approve</button>
                                    </form>
                                    <?php endif; ?>

                                    <?php if($user->status == true): ?>
                                    <button class="btn btn-link text-success">Active</button>
                                    <?php else: ?>
                                    <button class="btn btn-link text-warning">Pending Approval</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <section class="section">
            <div class="card">
                <div class="card-header">
                    <h4>All Jobs</h4>
                </div>
                <div class="card-body p-3">
                    <div class="table-responsive">
                        <table class="table table-striped" id="jobsTable">
                            <thead>
                                <tr>
                                    <th>Job ID</th>
                                    <th>Title</th>
                                    <th>Duration</th>
                                    <th>Location</th>
                                    <th>Company</th>
                                    <th>Rate</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $category->Jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <form action="<?php echo e(route('assignJob', $user->id)); ?>" method="post">
                                        <td><?php echo e($job->id); ?></td>
                                        <td><?php echo e($job->title); ?></td>
                                        <td><?php echo e($job->duration); ?></td>
                                        <td><?php echo e($job->location); ?></td>
                                        <td><?php echo e($job->company); ?></td>
                                        <td><?php echo e($job->rate); ?>/ <?php echo e($job->paymentMode); ?></td>
                                        <td>
                                            <input type="date" required style="width: 100px" id="start_on" class="form-control" name="start_on">
                                        </td>
                                        <td>
                                            <input type="date" id="end_on" style="width: 100px" class="form-control" name="end_on" placeholder="End date">
                                        </td>
                                        <?php if($job->location == $user->Profile->location || $user->isRelocate == "Yes"): ?>
                                        <td>
                                            <?php echo csrf_field(); ?>
                                            <input type="text" name="job" value="<?php echo e($job->id); ?>" hidden>
                                            <button type="submit" class="btn filled-button">Assign</button>
                                        </td>
                                        <?php else: ?>
                                        <td>
                                            <a href="#?" class="btn btn-outline-danger disabled">Not Applicable</a>
                                        </td>
                                        <?php endif; ?>
                                    </form>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>

        </section>

    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("scripts"); ?>
<script>
    $(".nav-tabs").on('click', "li", function() {
        $(".tab").removeClass("active");
        var thisid = $(this).attr("data-toggle")

        $(".tab-content #" + thisid).addClass("active")

        $(".nav-tabs li a").removeClass("active")
        $("#" + thisid + " a").addClass("active")
        console.log(thisid);
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.management", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yemi Maxedge\laravel\SmartForce\resources\views/job/assign.blade.php ENDPATH**/ ?>