


<?php $__env->startSection("content"); ?>


<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-4 col-md-6">
            <div class="card border-0 shadow rounded bg-white p-4 sticky-bar">
                <div class="mt-4">
                    <h4 class="title mb-3">
                        <h4 class="title text-dark mb-3"> <?php echo e($job->title); ?> </h4>
                    </h4>
                    <p class="para-desc text-muted"><?php echo e(substr($job->description, 0, 100)); ?></p>
                    <ul class="list-unstyled mb-0">
                        <li class="list-inline-item mb-0 text-primary me-3"><span class="iconify" data-icon="akar-icons:location"></span><?php echo e($job->location); ?></li>
                        <li class="list-inline-item mb-0 text-primary"><span class="iconify" data-icon="carbon:dashboard-reference"></span><?php echo e($job->Category->title); ?></li>
                    </ul>
                </div>
            </div>
        </div>
        <!--end col-->

        <div class="col-lg-8">
            <div class="sidebar border-0">
                <h3 class="mb-0">Job Information</h3>
            </div>

            <div class="mt-4">
                <h5>Job Description: </h5>
                <div class="text-muted">
                    <p><?php echo e($job->description); ?></p>
                </div>



                <div class="row gx-3 gy-3">
                    <div class="col-lg-4 col-md-6">
                        <small>Location</small>
                        <p><?php echo e($job->location); ?></p>
                    </div>

                    <div class="col-lg-4 col-md-6">
                        <small>Company</small>
                        <p><?php echo e($job->company); ?></p>
                    </div>

                    <div class="col-lg-4 col-md-6">
                        <small>Payment Mode</small>
                        <p><?php echo e($job->paymentMode); ?></p>
                    </div>

                    <div class="col-lg-4 col-md-6">
                        <small>Rate</small>
                        <p><?php echo e($job->rate); ?></p>
                    </div>

                    <div class="col-lg-4 col-md-6">
                        <small>Duration</small>
                        <p><?php echo e($job->duration); ?></p>
                    </div>

                    <div class="col-lg-4 col-md-6">
                        <small>Category</small>
                        <p><?php echo e($job->Category->title); ?></p>
                    </div>

                    <!-- title, category_id, duration, rate, description, location, company, paymentMode -->
                </div>

                <div class="mt-4 d-flex justify-content-between">
                    <a href="/management/job/edit/<?php echo e($job->id); ?>" class="btn btn-outline-primary">Update <i class="mdi mdi-send"></i></a>
                    <a href="/management/job/delete/<?php echo e($job->id); ?>" class="btn btn-outline-danger">Delete <i class="mdi mdi-send"></i></a>
                </div>
            </div>

        </div>
        <!--end col-->
    </div>
    <!--end row-->
</div>
<!--end container-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.management", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yemi Maxedge\laravel\SmartForce\resources\views/job/show.blade.php ENDPATH**/ ?>