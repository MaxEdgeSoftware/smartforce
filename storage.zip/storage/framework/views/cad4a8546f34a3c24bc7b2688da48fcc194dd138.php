


<?php $__env->startSection("content"); ?>
<div class="page_header">
    <h3 class="text-dark"><?php echo e($page); ?> Candidates</h3>
</div>

<section>
    <div class="card p-2">
        <div class="card-header">
            <h4>Candidates</h4>
        </div>
        <div class="card-body p-3">
            <div class="table-responsive">
                <table class="table table-striped" id="agentsTable">
                    <thead>
                        <tr>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Mobile</th>
                            <th>Gender</th>
                            <th>Interest</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $regcomplete; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                            <td><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->Profile->mobile); ?></td>
                            <td><?php echo e($user->Profile->gender); ?></td>
                            <td><?php echo e($user->Profile->Pinterest->title); ?></td>
                            <td>
                                <?php if($user->status == true): ?>
                                <span class="text-uppercase badge badge-success">Verified</span>
                                <?php else: ?>
                                <span class="text-uppercase badge badge-danger">Not Verified</span>
                                <?php endif; ?>
                            </td>
                            <td><a href="/management/user/<?php echo e($user->id); ?>" class="btn btn-success">View</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.management", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yemi Maxedge\laravel\SmartForce\resources\views/management/users.blade.php ENDPATH**/ ?>