


<?php $__env->startSection("content"); ?>
<div class="page_header">
    <h3 class="text-dark">WORK DETAILS </h3>
</div>

<section class="section">
    <div class="container px-md-1">
        <div class="">
            <div class="card profile-header">
                <div class="body">
                    <div class="row py-3 px-3">
                        <div class="col-md-6 col-12">
                            <div class="profile-image p-2">
                                <h3><?php echo e($userjob->Job->title); ?></h3>
                                <a href="management/job/<?php echo e($userjob->Job->id); ?>">view job details</a><br>
                                <pay-user jobname="<?php echo e($userjob->Job->title); ?>" userjobid="<?php echo e($userjob->id); ?>" rate=" <?php echo e($userjob->Job->rate); ?>" jobid="<?php echo e($userjob->Job->id); ?>" username="<?php echo e($userjob->Worker->name); ?>" userid="<?php echo e($userjob->Worker->id); ?>" paymentmode="<?php echo e($userjob->Job->paymentMode); ?>"></pay-user>
                            </div>
                        </div>
                        <div class="col-md-6 col-12">
                            <div class="profile-image text-center">
                                <img src="/storage/<?php echo e($userjob->Worker->Profile->picture); ?>" alt="<?php echo e($userjob->Worker->name); ?>" class="my-2" /> <br>
                                <h4><?php echo e($userjob->Worker->name); ?></h4>
                                <a href=" /management/user/<?php echo e($userjob->Worker->id); ?>">View User</a>
                            </div>
                        </div>
                        <div class="col-12 my-5">
                            <h6>Transaction History</h6>
                            <table class="table table-striped" id="agentsTable">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($transaction->date); ?></td>
                                        <td>&#163;<?php echo e($transaction->amount); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("scripts"); ?>
<script>
    $(".nav-tabs").on('click', "li", function() {
        $(".tab").removeClass("active");
        var thisid = $(this).attr("data-toggle")

        $(".tab-content #" + thisid).addClass("active")

        $(".nav-tabs li a").removeClass("active")
        $("#" + thisid + " a").addClass("active")
        console.log(thisid);
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.management", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yemi Maxedge\laravel\SmartForce\resources\views/userjob/work.blade.php ENDPATH**/ ?>