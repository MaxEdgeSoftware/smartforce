


<?php $__env->startSection("content"); ?>
<section>
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card p-3 rounded">
                    <form action="<?php echo e(route('addIndustry')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="header">
                            <h5 class="color_primary">Add New Industry </h5>
                        </div>
                        <div class="body">
                            <div class="row clearfix">
                                <div class="col-sm-12">

                                    <?php if(Session::has('success')): ?>
                                    <div class="alert alert-success">
                                        Industry added successfully.... <a class="btn btn-link" href="/management/jobs">Go to jobs</a>
                                    </div>
                                    <?php endif; ?>

                                    <ul class="text-danger">
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>

                                    <div class="form-group form-float">
                                        <div class="form-line">
                                            <input name="title" type="text" class="form-control">
                                            <label class="form-label">Title </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <input type="file" class="form-control" name="image" id="category_image" accept=".jpg, .png, .jpeg">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <button class="btn btn-icon">ADD <span class="fa fa-arrow-right"></span></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("scripts"); ?>
<script>

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.management", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yemi Maxedge\laravel\SmartForce\resources\views/categories/add.blade.php ENDPATH**/ ?>